package com.example.csis3275midterm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csis3275Winter2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
