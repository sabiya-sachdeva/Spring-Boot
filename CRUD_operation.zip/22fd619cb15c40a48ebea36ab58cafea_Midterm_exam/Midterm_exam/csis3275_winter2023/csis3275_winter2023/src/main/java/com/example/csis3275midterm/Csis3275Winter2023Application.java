package com.example.csis3275midterm;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.csis3275midterm.model.Book;
import com.example.csis3275midterm.repo.BookRepo;

@SpringBootApplication
public class Csis3275Winter2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Csis3275Winter2023Application.class, args);
	}
	
	
	@Bean
	ApplicationRunner init(BookRepo bookrepo)
	{

	ApplicationRunner runner=new ApplicationRunner()
	{

		@Override
		public void run(ApplicationArguments args) throws Exception {
			
			bookrepo.save(new Book("Night Night Farm","Roger Priddy",20));
			bookrepo.save(new Book("The Office:A Day at Dunder Miffin Elementary","Robb Pearlman",40));
			bookrepo.save(new Book("Just Go to bed","Mercer Mayer",24));
			
			// TODO Auto-generated method stub
			
		}
		
		
	
	};
	return runner;

}
}