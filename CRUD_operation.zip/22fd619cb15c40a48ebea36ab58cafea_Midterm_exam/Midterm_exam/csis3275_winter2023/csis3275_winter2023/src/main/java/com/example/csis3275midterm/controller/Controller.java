package com.example.csis3275midterm.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.csis3275midterm.model.Book;
import com.example.csis3275midterm.repo.BookRepo;

@RestController
@RequestMapping("/api")
public class Controller {
	@Autowired
	BookRepo bookrepo;
	
	
	@GetMapping("/books")
	public ResponseEntity<List<Book>> getbooks(){
		List<Book> books=new ArrayList<>();
		try
		{
			List<Book> temp=bookrepo.findAll();	
			for(Book c:temp)
			{
				books.add(c);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity(books,HttpStatus.OK);
		
	}
	
	
	
	
	
	
	
	
	@GetMapping("/books/{id}")
	public ResponseEntity<Book> getbook(@PathVariable Long id){
		//List<Book> books=new ArrayList<>();
		try
		{
			Optional<Book> temp=bookrepo.findById(id);
			if(temp.isPresent())
			{
				return new ResponseEntity<>(temp.get(),HttpStatus.OK);
			}
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return new ResponseEntity(books,HttpStatus.OK);
		
	}
	
	
	

	@PostMapping("/books")
	public ResponseEntity<Book> createbook(@RequestBody Book entry){
		//List<Book> books=new ArrayList<>();
		try
		{
			Book newentry=new Book(entry.getTitle(),entry.getAuthorname(),entry.getPages());
			bookrepo.save(newentry);
			return new ResponseEntity<>(newentry,HttpStatus.NO_CONTENT);
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return new ResponseEntity(books,HttpStatus.OK);
		
	}
	
	
	@PutMapping("/books/{id}")
	public ResponseEntity<Book> updatebook(@PathVariable("id") Long id,@RequestBody Book entry){
		//List<Book> books=new ArrayList<>();
		try
		{
			Optional<Book> temp1=bookrepo.findById(id);
		if(temp1.isPresent())
		{
			Book _book=temp1.get();
			_book.setTitle(entry.getTitle());
			_book.setAuthorname(entry.getAuthorname());
			_book.setPages(entry.getPages());
			return new ResponseEntity<>(bookrepo.save(_book),HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return new ResponseEntity(books,HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/books")
	public ResponseEntity<HttpStatus> deletebooks(){
		//List<Book> books=new ArrayList<>();
		try
		{
			//Optional<Book> temp=bookrepo.findById(id);
			bookrepo.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return new ResponseEntity(books,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/books/{id}")
	public ResponseEntity<HttpStatus> deletebook(@PathVariable("id") Long id)
	{
		//List<Book> books=new ArrayList<>();
		try
		{
			bookrepo.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception e)
		{
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		//return new ResponseEntity(books,HttpStatus.OK);
		
	}
	

}
