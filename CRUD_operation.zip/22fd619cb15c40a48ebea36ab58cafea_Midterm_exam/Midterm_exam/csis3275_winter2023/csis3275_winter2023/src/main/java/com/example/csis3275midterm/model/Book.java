/*Create the entity class called Book, 
which has a system-generated id (long), title (String), authors (ArrayList of String), pages (int);

Create the repository class for save/create/update/delete the entity class Book;

When starting the application, it will save the following books to the database:

Record	   Title	         Authors	  Pages
1      Night Night Farm  Roger Priddy    20



2	The Office: A Day at Dunder Mifflin Elementary Robb Pearlman,Melanie Demmer 40




3	Just Go to Bed (Little Critter)   Mercer Mayer  24





Use h2-console to check the creation of the table and the above Book records.
Create the controller class which supports the following RESTful APIs (or endpoints), using appropriate mappings:
 	RESTful API (or endpoint)	Description
1.	/api/books	This API (or endpoint) will return the list of all Book records in the database
2.	/api/books/{id}	This API (or endpoint) will return the Book record with {id}
3.	/api/books	This API (or endpoint) will create a new Book record in the database, given the Book object in RequestBody.
4.	/api/books	This API (or endpoint) will delete all Book records in the database.
5.	/api/books/{id}	This API (or endpoint) will delete an exiting Book record with {id} in the database.
*/


package com.example.csis3275midterm.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Booktable")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	@Column(name="title")
	String Title;
	@Column(name="name")
	String authorname;
	@Column(name="pages")
	int pages;
	public Book() {
		super();
	}
	public Book(String title, String authorname, int pages) {
		super();
		Title = title;
		this.authorname = authorname;
		this.pages = pages;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getAuthorname() {
		return authorname;
	}
	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	

}
